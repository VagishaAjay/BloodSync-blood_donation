package com.example.blood_sync

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
